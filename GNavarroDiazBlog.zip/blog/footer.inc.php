<?php
print <<<HERE
	<footer>
		<div class="footer">
			All rights reserved. German Navarro&reg 2018.
		</div>
	</footer>
HERE;
?>		