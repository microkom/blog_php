<?php
print <<<HERE
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css" /> 
    <link href="favicon.ico" rel="icon" type="image/x-icon" />
HERE;
?>