<?php

$raiz = "./";
$principal = "./";
$login = "./login.php";
$registro = "./registro.php";
$comentarios = "./comentarios.php?accion=todosLosComentarios";
$entradas = "login.php";
$crear = "editarCrear.php?accion=crear";
$todo = "principal.php?accion=todosLasEntradas";
$borrar = "login.php";
?>