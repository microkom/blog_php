<?php
print <<<HERE
	<footer>
		<section class="footer">
			All rights reserved. German Navarro&reg 2018.
		</section>
	</footer>
HERE;
?>		