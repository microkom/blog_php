<?php
/*
Clase BD - contendrá los siguientes campos:
�? Array de entradas.
�? Array de usuarios.
*/

Class BD{



    public $entrada = array();
    public $usuario = array();


    public function addEntrada($entrada) {
        $this->entrada[] = $entrada;
    }

    public function readEntrada($idEntrada) {   //por idEntrada
        foreach( $this->entrada as $value){
            if($value->idEntrada === (string)$idEntrada)
                return $value;
        }        
    }
    public function borrarEntrada($idEntrada) {   //por idEntrada

        foreach( $this->entrada as $key => $objetoEntrada){
            if($objetoEntrada->idEntrada === (string)$idEntrada){
                unset($this->entrada[$key]);
                return true;
            }
        }

    }
    public function busqueda($busquedaArr, $tipo) {   //por string
        $idEntrada = array();

        //busca 1 o más palabras en el array que recibe
        if($tipo === 0){

            foreach($busquedaArr as $busqueda){
                $busqueda = trim($busqueda);
                $busqueda = strtolower($busqueda);
                foreach( $this->entrada as $key => $objetoEntrada){
                    $texto = explode(' ',$objetoEntrada->texto);
                    $titulo = explode(' ',$objetoEntrada->titulo);

                    $texto = quitarAcentos($texto);
                    $titulo = quitarAcentos($titulo);

                    foreach($texto as $palabra){
                        if((strcasecmp($busqueda,$palabra))==0)
                            $idEntrada[] = $objetoEntrada->idEntrada;
                    } 
                    foreach($titulo as $palabra){
                        if((strcasecmp($busqueda,$palabra))==0)
                            $idEntrada[] = $objetoEntrada->idEntrada;
                    }
                    $idEntrada = array_unique($idEntrada);
                }

            }
        }else{

            //busca frases completas
            $busqueda = trim($busquedaArr);//busquedaArr aquí no es Array
            $busqueda = strtolower($busqueda);
            foreach( $this->entrada as $key => $objetoEntrada){

                $texto =  $objetoEntrada->texto;
                $titulo = $objetoEntrada->titulo;

                $texto = quitarAcentos($texto);
                $titulo = quitarAcentos($titulo);

                if(strpos(strtolower($texto),$busqueda) !== false){
                    $idEntrada[] = $objetoEntrada->idEntrada;
                }
                if(strpos(strtolower($titulo),$busqueda) !== false){
                    $idEntrada[] = $objetoEntrada->idEntrada;
                }


            }

            $idEntrada = array_unique($idEntrada);
        }
        return $idEntrada;   
    }

    public function getTotalEntradas() {   //Devuelve 
        $contador=0;
        foreach( $this->entrada as $value){
            $contador++;

        }       
        return $contador;
    }

    public function readEntradaIndice($indice) { //por �ndice
        return  $this->entrada[$indice];        
    }
    public function addUsuario($usuario) {
        $this->usuario[] = $usuario;
    }

    public function existeUsuario($usuario, $pass) {
        foreach($this->usuario as $value){
            $usuario3 = strtolower($usuario);
            $usuario2 = strtolower($value->user);
            if($usuario3 == $usuario2 && $value->pass == $pass){
                return $value->user;
            }
        }
        return false;
    }

    public function readUsuario($usuario) {
        return  $this->usuario[$usuario];
    }

    //Función que borra una entraa usando un índice
    //    public function delE($index) {
    //        unset( $this->contactos[$index]);
    //    }
    //    
    ////    public function __toString() {
    //		$allText ="";
    //        foreach( $this->contactos as  $value){
    //          $allText .= $value->__toString();  
    //        }
    //		return $allText;
    //    }



    /*
	private $entrada = array();
	private $usuario = array();

	public function __construct($entrada=array(), $usuario=array()){
		$this->entrada = $entrada;
		$this->usuario = $usuario;
	}

	public function setEntrada($entrada){
		$this->entrada[] = $entrada;
	}
	public function setUsuario($usuario){
		$this->usuario[] = $usuario;
	}
	public function getEntrada(){
		return $this->entrada;
	}
	public function getUsuario(){
		return $this->usuario;
	}
*/	
    //        public function __construct($arg_nombre="",$arg_notas=array()) //funcion que se autoejecuta cuando defines un objeto, le puedes poner argumentos de inicialización, por defecto todo es vacio
    //    {
    //        $this->nombre=$arg_nombre; //ponemos el argumento pasado cuando defines el objeto
    //        $this->notas=$arg_notas;
    //    }
}
?>
