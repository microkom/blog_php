<?php

if(isset($_SESSION['userLogged']))
    $userLogged = $_SESSION['userLogged'];

if(isset($_SESSION['entradaArr']))
    $entradaArr = $_SESSION['entradaArr'];


require_once 'dbaseInfo.php'; //no borrar

function todosLosComentarios($entradaArr){
    foreach($entradaArr->entrada as $objetoEntrada){
        comentarios($objetoEntrada);
    }
}
function todosLasEntradas($entradaArr){
    foreach($entradaArr->entrada as $objetoEntrada){
        imprimirEntradaResumida($objetoEntrada);
    }
}

function mostrarBusqueda($entradaArr, $idArr){

    foreach($idArr as $idEntrada){

        $objetoEntrada = $entradaArr->readEntrada($idEntrada);
        if($objetoEntrada->idEntrada == $idEntrada){

            //título del artículo
            print "<ul><li><h4><a href=\"./principal.php?idEntrada=$idEntrada&accion=mostrar\">$objetoEntrada->titulo</a></h4>";


            //mostrar usuario, fecha hora, contador comentarios
            print '
				<div>

				<div> '._mostrarUsuarioFechaHora($objetoEntrada).'</div>
				<div><a href="./principal.php?idEntrada='.$idEntrada.'&accion=mostrar">Comentarios: '._contadorComentarios($objetoEntrada).'</a>
				</div>

				</div>
				<br>';

            _mostrarEditarBorrarEntrada($objetoEntrada,$idEntrada);

            print " </li></ul>";

        }else{
            print "No hay conincidencias con la búsqueda.";

        }
    }
}

function comentarios($objetoEntrada){

    $idEntrada = $objetoEntrada->idEntrada;
    //título del artículo
    print "<h3>$objetoEntrada->titulo</h3>";


    print "...<a href=\"./principal.php?idEntrada=$idEntrada&accion=mostrar\">Leer mas.</a>";


    //Contador de comentarios
    $comments  =$objetoEntrada->comentario ;

    //Usuario y fecha update
    print "<table class=\"w100\"  ><tr><td>";
    print"<h4>".$objetoEntrada->usuario."   ".dateTime($objetoEntrada->fechaHora)."</h4>";
    print "</td>";


    print "</tr><tr><td>";

    _mostrarComentarioCompleto($objetoEntrada);

    print "</td></tr></table>";

    print '<a href="principal.php?idEntrada='.$idEntrada.'&accion=comentar">Agregar Comentario</a>';
}

function _mostrarComentarioCompleto($objetoEntrada){


    print "<h3>COMENTARIOS</h3>";
    //array de comentarios
    $commentarioArr = $objetoEntrada->getComentario();

    //muestra cada comentario
    foreach($commentarioArr as $commentario){

        //autor del comentario + texto del comentario
        print "<ul><li>".$commentario->autor.":<br>".$commentario->texto."<br>";   

        //fechahora del comentario
        print "<h5>".dateTime($objetoEntrada->getFechaHora())."</h5> ";

        $controlUsuario = $objetoEntrada->usuario; 
        if(isset($_SESSION['usuario']) && $_SESSION['usuario'] === $controlUsuario){
            print '
        <a href="principal.php?idEntrada='.$objetoEntrada->idEntrada. '&idComentario=' .$commentario->idComentario. '&accion=editarComentario">
        <img src="edit_small.png" alt="Editar Comentario" title="Editar Comentario"></a>

        <a href="principal.php?idEntrada=' .$objetoEntrada->idEntrada. '&idComentario=' .$commentario->idComentario. '&accion=warningBorrarComentario">
        <img src="bin_small.png" alt="Borrar Comentario" title="Borrar Comentario"></a>

        </li></ul>';

        }else{
            print '</li></ul>';
        }
    }
    print "<br>";
}

function warningBorrarEntrada($objetoEntrada){

    $idEntrada = $objetoEntrada->idEntrada;

    print "Se va a proceder al borrado de la entrada con título:
    <h5>$objetoEntrada->titulo</h5>
    Confirma el borrado de dicha entrada?  
    <a href=\"principal.php?idEntrada=$idEntrada&accion=borrarEntrada\">Borrar</a> 
    <a href=\"login.php\">Anular</a>";

}

function borrarEntrada($entradaArr, $idEntrada){

    $borrado = $entradaArr->borrarEntrada($idEntrada);
    if($borrado)
        print "Entrada borrada.";
    else
        print "Fallo al borrar la entrada.";
    $_SESSION['entradaArr'] = $entradaArr;

}

function warningBorrarComentario($objetoEntrada,$idEntrada,$idComentario){

    //$comentarioArr = $objetoEntrada->comentario;
    $comentarioArr = $objetoEntrada->comentario;

    foreach($comentarioArr as $comentario ){
        if($comentario->idComentario === $idComentario){
            $comentarioBorrar = $comentario->texto;
        }
    }
    //var_dump($comentarioArr);exit();
    print "Se va a proceder al borrado del comentario :<br><br>
    <h5> $comentarioBorrar </h5> <br> <br> Confirma el borrado?  
    <a href=\"principal.php?idEntrada=$idEntrada&accion=borrarComentario&idComentario=$idComentario\">Borrar</a> 
    <a href=\"login.php\">Anular</a>";

}

function borrarComentario($entradaArr,$idEntrada,$idComentario){

    $objetoEntrada = $entradaArr->readEntrada($idEntrada);
    $borrado = $objetoEntrada->borrarComentario($idComentario);

    if($borrado)
        print "Comentario borrado.";
    else
        print "Fallo al borrar el comentario.";
    $_SESSION['entradaArr'] = $entradaArr;

}

function imprimirEntradaResumida($objetoEntrada){  //llamado con accion=mostrar

    $idEntrada = $objetoEntrada->idEntrada;
    //título del artículo
    print "<article><h3><a href=\"principal.php?idEntrada=$idEntrada&accion=mostrar\">$objetoEntrada->titulo</a></h3>";

    //Fraccionamiento del articulo para mostrar las 30 primeras palabras
    $textoEntrada = $objetoEntrada->texto;
    $textoEntrada = explode(' ', $textoEntrada);
    $textoEntrada = array_slice($textoEntrada,0,30);
    $textoEntrada = implode(' ', $textoEntrada);

    //mostrar texto del artículo
    print $textoEntrada;

    //mostrar texto del artículo
    print "...<a href=\"./principal.php?idEntrada=$idEntrada&accion=mostrar\">Leer mas.</a><br><br>";

    //mostrar usuario, fecha hora, contador comentarios
    print '<div><div> '._mostrarUsuarioFechaHora($objetoEntrada).'</div><div> <a href="./principal.php?idEntrada='.$idEntrada.'&accion=mostrarComentario">Comentarios: '._contadorComentarios($objetoEntrada).'</a></div></div><br>';

    _mostrarEditarBorrarEntrada($objetoEntrada,$idEntrada);
    print "</article>";
}

function imprimirEntrada($entradaArr, $idEntrada){

    $objetoEntrada = $entradaArr->readEntrada($idEntrada);

    print "<aside>";
    _mostrarEditarBorrarEntrada($objetoEntrada,$idEntrada);
    print "</aside>";

    print "<h3>$objetoEntrada->titulo</h3>";

    //Texto del articulo
    $textoObjetoEnt =  nl2br($objetoEntrada->texto);
    print $textoObjetoEnt." <br>";


    //mostrar usuario, fecha hora, contador comentarios
    print '<br><div><div> '._mostrarUsuarioFechaHora($objetoEntrada).'</div></div><br>';

    _mostrarComentarioCompleto($objetoEntrada);

    print '<a href="principal.php?idEntrada='.$idEntrada.'&accion=comentar">Agregar Comentario</a>';
}

function imprimirTituloEntrada($objetoEntrada){

    $idEntrada = $objetoEntrada->idEntrada;
    //título del artículo
    print "<article><h3>$objetoEntrada->titulo</h3>";

    //mostrar texto del artículo
    print "...<a href=\"./principal.php?idEntrada=$idEntrada&accion=mostrar\">Leer mas.</a><br><br>";

    //mostrar usuario, fecha hora, contador comentarios
    print '<div><div> '._mostrarUsuarioFechaHora($objetoEntrada).'</div><div> <a href="./principal.php?idEntrada='.$idEntrada.'&accion=mostrar">Comentarios: '._contadorComentarios($objetoEntrada).'</a></div></div><br>';

    _mostrarEditarBorrarEntrada($objetoEntrada,$idEntrada);

    print "</td></tr></table></article>";
}

function _mostrarEditarBorrarEntrada($objetoEntrada,$idEntrada){
    $controlUsuario = $objetoEntrada->usuario; 
    if(isset($_SESSION['usuario']) && $_SESSION['usuario'] === $controlUsuario){
        print '
        <a href="principal.php?idEntrada='.$idEntrada.'&accion=editarEntrada">
        <img src="edit_small.png" alt="Editar Entrada" title="Editar Entrada"></a>
        <a href="principal.php?idEntrada='.$idEntrada.'&accion=warningBorrarEntrada">
        <img src="bin_small.png" alt="Borrar Entrada" title="Borrar Entrada"></a>';
    }
}

function editarEntrada($entradaArr, $idEntrada){

    print "<form action=".$_SERVER['PHP_SELF']." method=\"post\">";

    $objetoEntrada = $entradaArr->readEntrada($idEntrada);
    print "<label for='titulo'>Titulo</label><br>
    <input type='text' size='50'  name='titulo' value='$objetoEntrada->titulo'>";

    $texto =  ($objetoEntrada->texto);//nl2br agrega <br/>
    $texto = br2nl($texto);

    //Texto del articulo
    print "<br><br><label for=\"articulo\">Articulo</label><br>
     <textarea rows=\"22\" cols=\"70\" name=\"texto\">$texto</textarea><br>";

    $fechaHora = date('Ymdhis');
    //autor y fecha
    print "<table class=\"w100\"  ><tr><td>";
    print "<h5>".$objetoEntrada->usuario."</h5> </td><td class=\"right\"> <h5>".dateTime($objetoEntrada->getFechaHora())."</h5></td></tr>

    <input type=\"hidden\" name=\"fechaHora\" value=\"$fechaHora\">
    <input type=\"hidden\" name=\"idEntrada\" value=\"$idEntrada\">
    <tr><td><input type=\"submit\" name=\"guardar\" value=\"Guardar\"></td></tr>
    </table></form>";

    _mostrarComentarioCompleto($objetoEntrada);


}

function comentarioDeArray($comentarioArr,$idComentario){
    foreach($comentarioArr as $comentario ){
        if($comentario->idComentario === $idComentario){
            return $comentario;
        }
    }
}

function editarComentario($entradaArr, $idEntrada, $idComentario){

    print "<form action=".$_SERVER['PHP_SELF']." method=\"post\">";

    $objetoEntrada = $entradaArr->readEntrada($idEntrada);
    $comentarioArr = $objetoEntrada->comentario;
    $objetoComentario = comentarioDeArray($comentarioArr,$idComentario);

    print "<h3>$objetoEntrada->titulo</h3>Editar Comentario<br><br>";

    print "<label for='autor'>Autor</label><br>
    <input type='text' size='50'  name='autor' value='$objetoComentario->autor' disabled>";
    $texto=  $objetoComentario->texto;//nl2br agrega <br/>
    $texto = br2nl($texto);

    //Texto del Comentario
    print '<br><br>
    <label for="texto">Comentario</label>
    <br>
    <textarea rows="22" cols="70" name="texto" >'.$texto.'</textarea><br>';
    //var_dump($objetoComentario);exit();

    $fechaHora = date('Ymdhis');
    //autor y fecha
    print "<table class=\"w100\"  ><tr><td class=\"right\"> <h5>".dateTime($objetoComentario->fechaHora)."</h5></td> </tr>

    <input type=\"hidden\" name=\"fechaHora\" value=\"$fechaHora\">
    <input type=\"hidden\" name=\"idEntrada\" value=\"$idEntrada\">
    <input type=\"hidden\" name=\"idComentario\" value=\"$objetoComentario->idComentario\">

    <tr><td><input type=\"submit\" name=\"guardarCommentarioEditado\" value=\"Guardar\"></td></tr>
    </table></form>";


}

function crearEntrada($entradaArr){

    print '<h2 class="width100">CREACION DE ENTRADAS</h2>';

    //get last id
    $objetoEntrada = end($entradaArr->entrada);
    $lastIdEntrada = $objetoEntrada->idEntrada;
    $pos = strpos($lastIdEntrada, "E");
    $nextEntradaId = "E".((substr($lastIdEntrada, $pos+1,10))+1);

    print "Entrada: $nextEntradaId <br> <br>

    <form action=".$_SERVER['PHP_SELF']." method=\"post\">";

    print <<<HERE

    <label class="w100" for="titulo">Titulo</label><br>
    <input   class="width100" type="text"  name="titulo" >
    <br><br>
    <label for="texto">Articulo</label><br>
    <textarea class="w100" name="texto"></textarea>

 <!--   <form action="upload.php" method="post" enctype="multipart/form-data">
        Seleccionar imagen para subir:
        <input type="file" name="fileToUpload" id="fileToUpload"><br>  <br>  
        <input type="submit" value="Subir Imagen" name="submit">
     </form>
     -->
HERE;

    $fechaHora = date('Ymdhis');
    //autor y fecha
    print "<table class=\"w100\"  >";
    print "<tr><td>".$_SESSION['usuario']." </td><td> ".dateTime($fechaHora)."</td></tr><br>  <br>  
    <input type=\"hidden\" name=\"fechaHora\" value=\"$fechaHora\">
    <input type=\"hidden\" name=\"idEntrada\" value=\"$nextEntradaId\">
    <input type=\"hidden\" name=\"usuario\" value=\"".$_SESSION['usuario']."\">
        <tr>
            <td>
                <br>  <br>  
                <input type=\"submit\" name=\"crearEntrada\" value=\"Guardar\">
            </td>
        </tr>
    </table>
    </form>";

}

function comentar($entradaArr, $idEntrada){

    print "<form action=".$_SERVER['PHP_SELF']." method='post'>";

    $objetoEntrada = $entradaArr->readEntrada($idEntrada);

    $comentario = $objetoEntrada->getComentario();

    //get last comment id
    if(count($comentario)>0){
        $lastComment = end($comentario);
        $lastId = $lastComment->idComentario;
        $pos = strpos($lastId, "C");
        $nextCommentId = "C".((substr($lastId, $pos+1,10))+1);
    }else{
        $nextCommentId = "C1";
    }

    print "<h3>AÑADIR COMENTARIO</h3>";
    print "Se va a añadir un comentario a la entrada \"$idEntrada$nextCommentId\". Los comentarios pueden ser moderados por el administrador del blog<br><br><h3>$objetoEntrada->titulo</h3>";

    print "<label for='autor'>Nombre</label><br>
    <input type='text' size='20'  name='autor' >";

    //Texto del articulo
    print "<br><br><label for=\"texto\">Comentario</label><br>
     <textarea rows=\"16\" cols=\"50\" name=\"texto\" ></textarea><br>";
    $fechaHora = date('Ymdhis');

    print "<date >".dateTime(date('Ymdhis'))."</date> 
    <input type=\"hidden\" name=\"fechaHora\" value=\"$fechaHora\">
    <input type=\"hidden\" name=\"commentId\" value=\"$nextCommentId\">
    <input type=\"hidden\" name=\"idEntrada\" value=\"$idEntrada\">
   <br>
   <input type=\"submit\" name=\"guardarNuevoCommentario\" value=\"Guardar\"></form>
   <br>
   <br>
   <h4>Comentarios</h4>";

    _mostrarComentarioCompleto($objetoEntrada);


}

//muestra todas las entradas que coinciden con ano y fecha
function mostrarArchivo($entradaArr,  $year, $month){

    print "<h2>ARCHIVO</h2><ul><li><h3>$year</h3><ul><li><h3>".month($month)."</h3>";

    foreach($entradaArr->entrada as $objetoEntrada){

        $anyoMes = substr($objetoEntrada->fechaHora,0,6); 

        if($anyoMes == ($year.$month)){

            $idEntrada = $objetoEntrada->idEntrada;

            //título del artículo
            print "<ul><li><h4><a href=\"./principal.php?idEntrada=$idEntrada&accion=mostrar\">$objetoEntrada->titulo</a></h4>";

            /*//mostrar texto del artículo
            print "...<a href=\"./principal.php?idEntrada=$idEntrada&accion=mostrar\">Leer mas.</a><br><br>";
*/
            //mostrar usuario, fecha hora, contador comentarios
            print '<div><div> '._mostrarUsuarioFechaHora($objetoEntrada).'</div><div> <a href="./principal.php?idEntrada='.$idEntrada.'&accion=mostrar">Comentarios: '._contadorComentarios($objetoEntrada).'</a></div></div><br>';

            _mostrarEditarBorrarEntrada($objetoEntrada,$idEntrada);

            print " </li></ul><br><br>";
        }
    }
    print "</ul></li></ul></li>";
}

function _mostrarUsuarioFechaHora($objetoEntrada){
    return $objetoEntrada->usuario.'  ' .dateTime($objetoEntrada->fechaHora);
}

function _contadorComentarios($objetoEntrada){
    $comments  =$objetoEntrada->comentario ;
    if($comments>0)
        return sizeof($comments);
    else
        return 0;

}

//formato fecha-hora: dia, mes, año, hora, minutos
function dateTime($fechaHora){    

    $anyo = substr($fechaHora,0,4); 
    $mes = substr($fechaHora,4,2);
    $dia = substr($fechaHora,6,2);
    $hora = substr($fechaHora,8,2);
    $min = substr($fechaHora,10,2);

    return $dia."/".$mes."/".$anyo." ".$hora.":".$min;
}
//Conversión de meses en número a palabra
function month($month){
    switch($month){
        case 1:  return "Enero";break;
        case 2:  return "Febrero";break;
        case 3:  return "Marzo";break;
        case 4:  return "Abril";break;
        case 5:  return "Mayo";break;
        case 6:  return "Junio";break;
        case 7:  return "Julio";break;
        case 8:  return "Agosto";break;
        case 9:  return "Septiembre";break;
        case 10:  return "Octubre";break;
        case 11:  return "Noviembre";break;
        case 12:  return "Diciembre";break;


    }
}

function quitarAcentos($texto){
    $from = array(
        'á','À','Á','Â','Ã','Ä','Å',
        'ß','Ç',
        'È','É','Ê','Ë','é',
        'Ì','Í','Î','Ï','Ñ','í',
        'Ò','Ó','Ô','Õ','Ö','ó',
        'Ù','Ú','Û','Ü','ú');

    $to = array(
        'a','A','A','A','A','A','A',
        'B','C',
        'E','E','E','E','é',
        'I','I','I','I','N','i',
        'O','O','O','O','O','o',
        'U','U','U','U','u');

    $textoNuevo = str_replace($from, $to, $texto);
    return $textoNuevo;
}

//quita los <br /> del texto almacenado al mostrarlos
function br2nl($texto){
    return preg_replace('(<br />)', " ", $texto);
}
?>