<?php
/*
Clase Entrada - contendrá los siguientes campos:
● idEntrada: número identificativo.
● fechaHora: timestamp de la creación del comentario.
● titulo: título de la entrada.
● usuario: id del usuario que creó la entrada.
● comentarios: array con los comentarios de la entrada
*/

Class Entrada{
    private $idEntrada;
    private $fechaHora;
    private $titulo;
    private $usuario;
    private $texto;
    private $comentario = array();



    public function __construct($idEntrada, $fechaHora, $titulo, $usuario, $texto, $comentario=array()){
        $this->idEntrada = $idEntrada;
        $this->fechaHora = $fechaHora;
        $this->titulo = $titulo;
        $this->usuario = $usuario;
        $this->texto = $texto;
        $this->comentario = $comentario;

    }

    public function __set($atributo, $valor){
        $this->$atributo = $valor;
    }                    

    public function __get($atributo){
        return $this->$atributo;
    }

     public function borrarComentario($idComentario) {   //por idEntrada

        foreach( $this->comentario as $key => $objetoComentario){
           // var_dump($idComentario);exit();
            if($objetoComentario->idComentario === (string)$idComentario){
                unset($this->comentario[$key]);
                return true;
            }
        }

    }

    public function setIdEntrada($id){
        $this->idEntrada = $id;
    }
    public function setFechaHora($fechaHora){
        $this->fechaHora= $fechaHora;
    }
    public function setTitulo($titulo){
        $this->titulo = $titulo;
    }
    public function setUsuario($usuario){
        $this->usuario = $usuario;
    }
    public function setComentario($comentario){
        $this->comentario[] = $comentario;
    }

    public function getIdEntrada(){
        return $this->idEntrada;
    }
    public function getFechaHora(){
        return $this->fechaHora;
    }
    public function getTitulo(){
        return $this->titulo;
    }
    public function getUsuario(){
        return $this->usuario;
    }
    public function getComentario(){
        return $this->comentario;
    }


    public function __toString(){
        return "IdEntrada: ".$this->idEntrada." <br>
		FechaHora: ".$this->fechaHora." <br>
		Título: ".$this->titulo." <br>
		Usuario: ".$this->usuario." <br>
		Comentario: ";//.retCom()."<br>";
    }
    function retCom(){
        $valor="";
        foreach($this->comentario as $valor){
            $valor .= $valor." ";
        }        
        return $valor;    
    }
	
}
?>